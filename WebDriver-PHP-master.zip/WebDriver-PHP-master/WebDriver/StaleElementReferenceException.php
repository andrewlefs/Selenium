<?php

class WebDriver_StaleElementReferenceException extends Exception {
}
