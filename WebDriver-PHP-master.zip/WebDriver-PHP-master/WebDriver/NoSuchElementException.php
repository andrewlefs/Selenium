<?php

class WebDriver_NoSuchElementException extends PHPUnit_Framework_ExpectationFailedException {
}
