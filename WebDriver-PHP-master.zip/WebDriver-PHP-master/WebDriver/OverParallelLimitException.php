<?php

class WebDriver_OverParallelLimitException extends Exception {
}
